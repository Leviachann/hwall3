#include <iostream>
using namespace std;
class Product {
  char *name = nullptr;
  char *description = nullptr;
  int id;
  short discount;
  double price;

public:
  static int staticId;
  Product() {
    name = new char[100]{"bread"};
    description = new char[100]{"mega expensive"};
    price = 99.99;
    discount = 10;
  }
  Product(const char *n, const char *d, int idd, double p, short dc) {
    SetName(n);
    SetDescription(d);
    SetId(idd);
    SetDiscount(dc);
    SetPrice(p);
  }
  void Showproduct() {
    cout << "Name: " << name << "\nDescription: " << description
         << "\nId: " << id << "\nPrice: " << price << "\nDiscount: " << discount
         << endl;
  }
  void SetName(const char *n) {
    delete[] name;
    name = new char[strlen(n) + 1];
    strcpy_s(name, strlen(n) + 1, n);
  }
  void SetDescription(const char *d) {
    delete[] description;
    description = new char[strlen(d) + 1];
    strcpy_s(description, strlen(d) + 1, d);
  }
  double GetPriceWithDiscount() { return price - price * discount / 100; }
  int SetId(int idd) { id = staticId++; }
  void SetPrice(int p) { price = 0 < p && p < 100000000 ? p : 100; }
  int SetDiscount(int p) { discount = 0 < p && p < 100 ? p : 5; }
  int GetId() { return id; }
  double GetPrice() { return price; }
  int GetDiscount() { return discount; }
  const char *GetName() { return name; }
  const char *GetDescription() { return description; }
  ~Product() {
    delete[] name;
    delete[] description;
  }
};
class Stock {
  char *name;
  Product *products;
  int productCount = Product::staticId + 1;
  Stock(Product *prods, int size) {
    productCount = size;
    products = new Product[productCount];
    for (int i = 0; i < productCount; i++) {
      products[i].SetName(prods[i].GetName());
      products[i].SetId(prods[i].GetId());
      products[i].SetDiscount(prods[i].GetDiscount());
      products[i].SetDescription(prods[i].GetDescription());
      products[i].SetPrice(prods[i].GetPrice());
    }
  }
  void Print(int size) {
    productCount = size;
    for (size_t i = 0; i < productCount; i++) {
      products[i].Showproduct();
    }
  }
  Product &Getproduct(int id) {
    for (int i = 0; i < productCount; i++) {
      if (products[i].SetId(products[i].GetId()) == id) {
        return products[i];
      }
    }
  }
};
void AddProduct(Product *&prods, int size, Product &p) {
  Product *temp = new Product[size + 1];
  for (int i = 0; i < size; i++) {
    temp[i].SetId(prods[i].GetId());
    temp[i].SetName(prods[i].GetName());
    temp[i].SetDescription(prods[i].GetDescription());
    temp[i].SetPrice(prods[i].GetPrice());
    temp[i].SetDiscount(prods[i].GetDiscount());
  }
}
static int id = 1;
int main() {}