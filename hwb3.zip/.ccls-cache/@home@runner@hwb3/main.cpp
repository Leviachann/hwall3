#include <iostream>
using namespace std;
class Debtor {
  char *name = nullptr;
  char *surname = nullptr;
  char *liveAddress = nullptr;
  char *workAddress = nullptr;
  int objectId;
  long phoneNumber;
  double salary;
  double debt;
  bool hasLatePayment = false;

public:
  static int staticId;
  Debtor() {
    name = new char[100]{"Eyvazov Aydemir"};
    workAddress = new char[100]{"4567 Oddysey Avenue,Northfield,Canada"};
    liveAddress = new char[100]{"3596 Tennessee Avenue,Southfield,Michigan"};
    salary = 15000.99;
    phoneNumber = 6949959155;
    debt = 9999.99;
    hasLatePayment = true;
  }
  Debtor(const char *n, const char *sn, const char *wa, int oid, double s,
         long pn, const char *la, double db, bool hlp) {
    SetName(n);
    SetWorkAddress(wa);
    SetId(oid);
    SetPhoneNumber(pn);
    SetSalary(s);
    SetLiveAddress(la);
    SetDebt(db);
    HasLatePayment(hlp);
    SetSurname(sn);
  }
  void ShowDebtor() {
    cout << "Name: " << name << "\nWork Address: " << workAddress
         << "\nId: " << objectId << "\nSalary: " << salary
         << "\nPhoneNumber: " << phoneNumber
         << "\nLive Address: " << liveAddress << "\nDebt: " << debt
         << "Surname: " << surname << endl;
  }
  void SetName(const char *n) {
    delete[] name;
    name = new char[strlen(n) + 1];
    strcpy_s(name, strlen(n) + 1, n);
  }
  void SetSurname(const char *sn) {
    delete[] surname;
    name = new char[strlen(sn) + 1];
    strcpy_s(surname, strlen(sn) + 1, sn);
  }
  void SetWorkAddress(const char *wa) {
    delete[] workAddress;
    workAddress = new char[strlen(wa) + 1];
    strcpy_s(workAddress, strlen(wa) + 1, wa);
  }
  void SetLiveAddress(const char *la) {
    delete[] liveAddress;
    liveAddress = new char[strlen(la) + 1];
    strcpy_s(liveAddress, strlen(la) + 1, la);
  }
  void SetId(int idd) { objectId = staticId++; }
  double SetDebt(int db) { debt = db; }
  void SetSalary(int s) { salary = s; }
  bool SetHasLatePayment(bool hpl) { hasLatePayment = HasLatePayment(debt); }
  bool HasLatePayment(bool hlp) {
    if (debt > 900000)
      return true;
  }
  long SetPhoneNumber(int pn) { salary = 0 < pn && pn < 100 ? pn : 5; }
  int GetId() { return objectId; }
  double GetDebt() { return debt; }
  double GetSalary() { return salary; }
  long GetPhoneNumber() { return phoneNumber; }
  bool GetHasLatePayment() { return hasLatePayment; }
  const char *GetName() { return name; }
  const char *GetSurname() { return surname; }
  const char *GetWorkAddress() { return workAddress; }
  const char *GetLiveAddress() { return liveAddress; }
  ~Debtor() {
    delete[] name;
    delete[] workAddress;
    delete[] liveAddress;
    delete[] surname;
  }
};
class Bank {
  char *name;
  Debtor *debtors;
  int debtorsCount = Debtor::staticId + 1;
  Bank(Debtor *debts, int size) {
    debtorsCount = size;
    debtors = new Debtor[debtorsCount];
    for (int i = 0; i < debtorsCount; i++) {
      debtors[i].SetName(debts[i].GetName());
      debtors[i].SetId(debts[i].GetId());
      debtors[i].SetPhoneNumber(debts[i].GetPhoneNumber());
      debtors[i].SetWorkAddress(debts[i].GetWorkAddress());
      debtors[i].SetSalary(debts[i].GetSalary());
    }
  }
  void ShowAllDebtors(int size) {
    debtorsCount = size;
    for (size_t i = 0; i < debtorsCount; i++) {
      debtors[i].ShowDebtor();
    }
  }
  Debtor &GetLateDebtor() {
    for (int i = 0; i < debtorsCount; i++) {
      if (debtors[i].SetHasLatePayment(debtors[i].GetHasLatePayment()) ==
          true) {
        debtors[i].ShowDebtor();
      }
    }
  }
  Debtor &GetTooMuchDebtor(int debt) {
    for (int i = 0; i < debtorsCount; i++) {
      if (debtors[i].SetDebt(debtors[i].GetDebt()) > 1000.00) {
        debtors[i].ShowDebtor();
      }
    }
  }
};
void AddDebtor(Debtor *&debts, int size, Debtor &d) {
  Debtor *temp = new Debtor[size + 1];
  for (int i = 0; i < size; i++) {
    temp[i].SetId(debts[i].GetId());
    temp[i].SetName(debts[i].GetName());
    temp[i].SetSurname(debts[i].GetSurname());
    temp[i].SetWorkAddress(debts[i].GetWorkAddress());
    temp[i].SetLiveAddress(debts[i].GetLiveAddress());
    temp[i].SetSalary(debts[i].GetSalary());
    temp[i].SetDebt(debts[i].GetDebt());
    temp[i].SetHasLatePayment(debts[i].GetHasLatePayment());
    temp[i].SetPhoneNumber(debts[i].GetPhoneNumber());
  }
}
static int staticId = 1;
int main() {}