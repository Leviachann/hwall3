#include <iostream>
using namespace std;
class Fraction {
public:
  int numerator;
  int denominator;
  Fraction(int num, int don) {
    numerator = num;
    denominator = don;
  }
  Fraction Multiply(const Fraction &other) {
    int num = this->numerator * other.numerator;
    int den = this->denominator * other.denominator;
    return Fraction(num, den);
  }
  Fraction Add(const Fraction &other) {
    int num = this->numerator + other.numerator;
    int den = this->denominator + other.denominator;
    return Fraction(num, den);
  };
  Fraction Minus(const Fraction &other) {
    int num = this->numerator - other.numerator;
    int den = this->denominator - other.denominator;
    return Fraction(num, den);
  };
  Fraction Divide(const Fraction &other) {
    int den = this->numerator * other.numerator;
    int num = this->denominator * other.denominator;
    return Fraction(num, den);
  };
  Fraction Simplify(const Fraction &other) {
    int num = this->numerator;
    int den = this->denominator;
    int max = 0;
    for (int i = 0; i < 10; i++) {
      if (num % i == 0) {
        if (den % i == 0) {
          max = i;
        }
      }
    }

    return Fraction(num / max, den / max);
  };
  class Point {
    int x;
    int y;

  public:
    int GetX() { return x; }
    int GetY() { return y; }
    void SetX(int arg) { x = arg; }
    void SetY(int arg) { y = arg; }
    Point() {
      x = 0;
      y = 0;
    }
    Point(int x, int y) {
      this->x = x;
      this->y = y;
    }
    void Print() { cout << "X: " << x << "Y: " << y << endl; }
  };
  class Students {
    char *name = nullptr;
    char *surname = nullptr;
    char *speciality = nullptr;
    char *city = nullptr;
    int age, group_no;

  public:
    Students(const char *n, const char *s, int a, const char *ss, const char *c,
             int gn) {
      SetName(n);
      SetSurname(s);
      SetAge(a);
      SetSpeciality(ss);
      SetCity(c);
      SetGroupNo(gn);
    }
    void Print() {
      cout << "Name: " << name << "\nSurname: " << surname << "\nAge: " << age
           << endl;
    }
    void SetName(const char *n) {
      delete[] name;
      name = new char[strlen(n) + 1];
      strcpy_s(name, strlen(n) + 1, n);
    }
    void SetSurname(const char *s) {
      delete[] surname;
      surname = new char[strlen(s) + 1];
      strcpy_s(surname, strlen(s) + 1, s);
    }
    void SetCity(const char *c) {
      delete[] surname;
      city = new char[strlen(c) + 1];
      strcpy_s(city, strlen(c) + 1, c);
    }
    void SetSpeciality(const char *ss) {
      delete[] surname;
      speciality = new char[strlen(ss) + 1];
      strcpy_s(speciality, strlen(ss) + 1, ss);
    }
    void SetAge(int a) { age = 0 < a && a < 100 ? a : 18; }
    void SetGroupNo(int g) { group_no = 1 < g && g < 12 ? g : 6; }
    int GetAge() { return age; }
    int GetGroupNo() { return group_no; }
    const char *GetName() { return name; }
    const char *GetSurname() { return surname; }
    const char *GetCity() { return city; }
    const char *GetSpeciality() { return speciality; }
    ~Students() {
      delete[] name;
      delete[] surname;
      delete[] speciality;
      delete[] city;
    }
  };
  class Counter {
  public:
    int currentData;
    int min, max;
    Counter(int argMin, int argMax) {
      min = argMin, max = argMax;
      currentData = min;
    }
    void SetCurrent(int x) { currentData = x < max ? x : min; }
    int GetCurrent() { return currentData; }
    void Increment() { SetCurrent(currentData + 1); }
  };
  int main() {}